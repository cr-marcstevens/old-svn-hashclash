/**************************************************************************\
|
|    Copyright (C) 2009 Marc Stevens (hashclash AT marc-stevens.nl)
|
|    This program is free software: you can redistribute it and/or modify
|    it under the terms of the GNU General Public License as published by
|    the Free Software Foundation, either version 3 of the License, or
|    (at your option) any later version.
|
|    This program is distributed in the hope that it will be useful,
|    but WITHOUT ANY WARRANTY; without even the implied warranty of
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
|    GNU General Public License for more details.
|
|    You should have received a copy of the GNU General Public License
|    along with this program.  If not, see <http://www.gnu.org/licenses/>.
|
\**************************************************************************/

Requirements: make, gcc/g++, (optionally: boost C++ libraries)

Compilation using g++ is straightforward by running 
	'make'.

If you encounter errors with respect to boost libraries run 
	'make -f Makefile.make_boost'
This will first download and compile the boost libraries in a subdirectory
and then compile the near-collision attack against it.

Default compiler is g++, for other compilers edit the Makefile.
Default optimization flags are "-march=native -O2", 
these flags can be edited in the Makefile
These default flags are okay, but (far) better results are obtained 
with tuned optimization flags and using profiling.
